﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProblemSet1
{
    internal class Demo
    {

        public void sort_array()
        {


            int[] numbers = { 25, 47, 42, 56, 32 };



            int[] oddNumbers;
            int[] evenNumbers;

            int oddCount = 0;
            int evenCount = 0;

            // Count the number of odd and even integers
            foreach (int number in numbers)
            {
                if (number % 2 == 0)
                {
                    evenCount++;
                }
                else
                {
                    oddCount++;
                }
            }

            // Initialize the arrays with the appropriate sizes
            oddNumbers = new int[oddCount];
            evenNumbers = new int[evenCount];

            // Populate the odd and even arrays
            int oddIndex = 0;
            int evenIndex = 0;
            foreach (int number in numbers)
            {
                if (number % 2 == 0)
                {
                    evenNumbers[evenIndex] = number;
                    evenIndex++;
                }
                else
                {
                    oddNumbers[oddIndex] = number;
                    oddIndex++;
                }
            }

            // Print the odd numbers
            Console.WriteLine("Odd numbers:");
            foreach (int number in oddNumbers)
            {
                Console.Write(" " + number);
            }

            // Print the even numbers
            Console.WriteLine("\nEven numbers:");
            foreach (int number in evenNumbers)
            {
                Console.Write(" " + number);
            }
        }
    }
}
