﻿// Character Encoding Standard //

//string input_str = "Apple";//

using System.Text;
using ProblemSet1;


// question 4 
Console.WriteLine("\n\n");
Console.WriteLine("-----Question 4 ---");
Console.WriteLine("\n\n");


Demo d = new Demo();
d.sort_array();




// question 3 

Console.WriteLine("\n\n");
Console.WriteLine("-----Question 3 ---");
Console.WriteLine("\n\n");

string a1 = Console.ReadLine();
string b1 = Console.ReadLine(); ;
string c1 = Console.ReadLine(); ;

double a = Convert.ToDouble(a1);
double b = Convert.ToDouble(b1);
double c = Convert.ToDouble(c1);

double area = Triangle.TriangleArea(a, b, c);
Console.WriteLine("\nArea of the triangle: " + area);
Console.WriteLine("\n\n");



// question 2 

Console.WriteLine("\n\n");
Console.WriteLine("-----Question 2 ---");
Console.WriteLine("\n\n");

string word00 = "Supercalifragilisticexpialidocious";
int letterCount = word00.Length;
Console.WriteLine(letterCount);

string word01 = "Supercalifragilisticexpialidocious";
bool containsSubstring = word01.Contains("ice");
Console.WriteLine(containsSubstring);


string word1 = "Supercalifragilisticexpialidocious";
string word2 = "Honorificabilitudinitatibus";
string word3 = "Bababadalgharaghtakamminarronnkonn";

string longestWord = "";
if (word1.Length > word2.Length && word1.Length > word3.Length)
{
    longestWord = word1;
}
else if (word2.Length > word1.Length && word2.Length > word3.Length)
{
    longestWord = word2;
}
else
{
    longestWord = word3;
}

Console.WriteLine(longestWord);





string[] composers = { "Berlioz", "Borodin", "Brian", "Bartok", "Bellini", "Buxtehude", "Bernstein" };
Array.Sort(composers);
string firstComposer = composers[0];
string lastComposer = composers[composers.Length - 1];

Console.WriteLine("First Composer: " + firstComposer);
Console.WriteLine("Last Composer: " + lastComposer);



Console.WriteLine("\n\n");
Console.WriteLine("-----Question 5 ---");
Console.WriteLine("\n\n");

//question 5 a 

int x = 3;
int y = 4;
int x1 = 1;
int y1 = 2;
int x2 = 5;
int y2 = 6;


bool isInside = Inside(x, y, x1, y1, x2, y2);
Console.WriteLine("Is the point inside the rectangle? " + isInside);


static bool Inside(int x, int y, int x1, int y1, int x2, int y2)
{
    return (x >= x1 && x <= x2 && y >= y1 && y <= y2);
}



// question 5b

double[] point = new double[] { 1, 1 };

double[] rect1LowerLeft = new double[] { 0.3, 0.5 };
double[] rect1UpperRight = new double[] { 1.1, 0.7 };
bool isInRect1 = inside_last(point, rect1LowerLeft, rect1UpperRight);

double[] rect2LowerLeft = new double[] { 0.5, 0.2 };
double[] rect2UpperRight = new double[] { 1.1, 2 };
bool isInRect2 = inside_last(point, rect2LowerLeft, rect2UpperRight);

bool isInBothRectangles = isInRect1 && isInRect2;

Console.WriteLine("Is the point in both rectangles? " + isInBothRectangles);


static bool inside_last(double[] point, double[] lowerLeft, double[] upperRight)
{
    double x = point[0];
    double y = point[1];
    double minX = lowerLeft[0];
    double minY = lowerLeft[1];
    double maxX = upperRight[0];
    double maxY = upperRight[1];

    return x >= minX && x <= maxX && y >= minY && y <= maxY;
}





 
//ReadAscii readAscii = new ReadAscii();
//readAscii.PrintAscii();